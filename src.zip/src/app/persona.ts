export interface Persona {
    nombre: string
    apellidos: string
    edad: number
    dni: string
    cumpleanos: any
    colorFavorito: string
    sexo: string
} 